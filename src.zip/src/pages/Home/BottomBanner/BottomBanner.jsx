

const BottomBanner = () => {
    return (
        <div className="container mx-auto mb-12">
            <img className="w-full" src="https://i.ibb.co.com/Y4YT1PyQ/Frame-19-2.png" alt="" />
        </div>
    );
};

export default BottomBanner;