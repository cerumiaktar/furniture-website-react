

const AdBanner = () => {
    return (
        <div className="container mx-auto mb-12">
            <img className="w-full" src="https://i.ibb.co.com/7NLz9fCB/Frame-19.png" alt="" />
        </div>
    );
};

export default AdBanner;